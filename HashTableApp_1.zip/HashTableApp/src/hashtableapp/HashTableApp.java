
package hashtableapp;


public class HashTableApp {


    public static void main(String[] args) {
        
        HashTable ht1 = new HashTable(31);
        
        ht1.insertItem(new DataItem(1)); // вставка
        ht1.displayHashTable();
        
        ht1.insertItem(new DataItem(32)); // вставка на место где уже ключ 1
        ht1.displayHashTable();
        
        ht1.insertItem(new DataItem(63)); // вставка на место где уже ключ 1 и 32
        ht1.displayHashTable();
        
        ht1.insertItem(new DataItem(94)); // вставка на место где уже ключ 1 и 32 и 63
        ht1.displayHashTable();
        
        System.out.println("Find: " + ht1.findItem(94).getKey()); // проверка поиска с показом прохода хэш таблицы
        
        ht1.deleteItem(94); // проверка удаления
        ht1.displayHashTable();
        
        ht1.insertItem(new DataItem(31)); // проверка шагов поиска
        ht1.displayHashTable();
        
        System.out.println("Find: " + ht1.findItem(94).getKey()); // проверка увеличения шагов поиска
        
        ht1.insertItem(new DataItem(25));
        System.out.println("Find: " + ht1.findItem(94).getKey()); // проверка увеличения шагов поиска
        

        
    }
    
}
