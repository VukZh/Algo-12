package hashtableapp;

public class HashTable {

    private DataItem[] arrHash;
    private int size;
    private int countItem;
    DataItem noItem = new DataItem(-1);// отметка для ленивого удаления

    public HashTable(int s) {
        if (!isPrime(s)) {
            System.out.println("!!!!  число не простое  !!!!");
        }

        size = s;
        arrHash = new DataItem[size];
        countItem = 0;
    }

    private boolean isPrime(int n) { // проверка простого числа
        if (n < 2) {
            return false;
        }
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    private int newSize(int s) {
        for (int i = s * 2 + 1; i < s * 3; i++) { // ищем простое число для нового размера хэш таблицы
            if (isPrime(i)) {
                return i;
            }
        }
        return -1;
    }

    private int hashFunction1(int k) { // хэш функция
        return k % size;
    }

    private int hashFunction1NewSize(int k, int newSize) { // хэш функция 1 для нового размера хэш таблицы
        return k % newSize;
    }

    private int hashFunction2(int k) { // h2(k) = 1 + (k mod(M−1)) из уроков
        return k % (size - 1) + 1;
    }

    private int hashFunction2NewSize(int k, int newSize) { // хэш функция 2 для нового размера хэш таблицы
        return k % (newSize - 1) + 1;
    }

    public boolean insertItem(DataItem i) { // вставка, при одинаковом элементе - выход без вставки

        if (countItem == size) { // проверка на заполненность хэш таблицы и увеличение ее размера при полном заполнении
            resizeHashTable();
        }

        int key = i.getKey();
        int hash = hashFunction1(key);
        int step = hashFunction2(key);
        while (arrHash[hash] != null && arrHash[hash].getKey() != -1) {
            if (arrHash[hash].getKey() == key) // выход без вставки
            {
                return false;
            } else {
                hash = hash + step;
                System.out.println("s - " + step); //
                hash = hash % size; // возврат на начало хэш таблицы при увеличении > size
                System.out.println("h - " + hash); //
            }
        }
        arrHash[hash] = i;
        countItem++;
        return true;
    }

    public boolean deleteItem(int k) {
        int hash = hashFunction1(k);
        int step = hashFunction2(k);
        int countFind = 0;
        while (arrHash[hash] != null) {
            if (arrHash[hash].getKey() == k) {
                arrHash[hash] = noItem;
                countItem--;
                return true; // удалено
            }
            ++countFind;
            hash = hash + step;
            hash = hash % size;

            if (countFind >= size) {
                return false; // не найден элемент для удаления при полном проходе заполненной хэш таблицы
            }

        }
        return false; // не найдено
    }

    public DataItem findItem(int k) {
        int hash = hashFunction1(k);
        int step = hashFunction2(k);
        int countFind = 0;
        while (arrHash[hash] != null) {
            if (arrHash[hash].getKey() == k) {
                return arrHash[hash]; // вывод найденного объекта
            }
            ++countFind;
            hash = hash + step;
            hash = hash % size;

            if (countFind >= size) {
                return noItem; // не найден элемент при полном проходе заполненной хэш таблицы - не найдено
            }

        }
        return noItem; // -1 - если не найдено, тоже вывожу НетДанных
    }

    public void displayHashTable() {
        System.out.println("HashTable:");
        for (int i = 0; i < size; i++) {
            if (arrHash[i] != null) {
                if (arrHash[i].getKey() != -1) {
                    System.out.print(" " + arrHash[i].getKey() + " ");
                } else {
                    System.out.print(" NoD "); // нет данных после удаления
                }
            } else {
                System.out.print(" ___ ");
            }
        }
        System.out.println("");
    }

    public void resizeHashTable() {
        int key;
        int newsize = newSize(size);
        DataItem[] arrHashNewSize = new DataItem[newsize];
        int hash;
        int step;

        System.out.println("!!! Resize from " + size + " to " + newSize(size) + " !!!");

        for (int i = 0; i < size; i++) { // проход по старой хеш таблице и заполнение новой

            if (arrHash[i] != null) {
                key = arrHash[i].getKey();
            } else {
                key = -1;
            }

            if (arrHash[i] != null && key != -1) {

                hash = hashFunction1NewSize(key, newsize);
                step = hashFunction2NewSize(key, newsize);

                while (arrHashNewSize[hash] != null) {
                    hash = hash + step;
                    hash = hash % newsize;
                }
                arrHashNewSize[hash] = arrHash[i];
            }
        }

        arrHash = arrHashNewSize; // обновление хеш таблицы и ее размера
        size = newsize;

    }

}
