
package hashtableapp;


public class HashTableApp {


    public static void main(String[] args) {
        
        HashTable ht1 = new HashTable(20);
        
        ht1.insertItem(new DataItem(1)); // вставка
        ht1.insertItem(new DataItem(10)); // вставка
        ht1.displayHashTable(); // вывод
        ht1.insertItem(new DataItem(20));ht1.displayHashTable(); // вставка + вывод
        ht1.deleteItem(1);ht1.displayHashTable(); // удаление и проверка пометки удаления
        
        ht1.insertItem(new DataItem(1));ht1.displayHashTable(); // вставка на удаленную пометку
//        System.out.println(di_1.insertItem(new DataItem(1))); // проверка вставки с тем-же ключом
        ht1.displayHashTable();
        ht1.insertItem(new DataItem(99));ht1.displayHashTable();// вставка
        ht1.insertItem(new DataItem(21));ht1.displayHashTable();// вставка где уже ключ 1
        
        System.out.println("Find: " + ht1.findItem(10).getKey()); // проверки поиска
        System.out.println("Find: " + ht1.findItem(2).getKey());
        
        
    }
    
}
