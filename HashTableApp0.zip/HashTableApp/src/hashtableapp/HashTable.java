package hashtableapp;

public class HashTable {

    private DataItem[] arrHash;
    private int size;
    private int countItem;
    private final DataItem noItem = new DataItem(-1);// отметка для ленивого удаления

    HashTable(int s) {
        size = s;
        arrHash = new DataItem[size];
        countItem = 0;
    }

    private int hashFunction(int k) { // хэш функция
        return k % size;
    }

    private int hashFunctionNewSize(int k) { // хэш функция для нового размера хэш таблицы
        return k % (2 * size);
    }

    public boolean insertItem(DataItem i) { // вставка, при одинаковом элементе - выход без вставки

        if (countItem == size) { // проверка на заполненность хэш таблицы и увеличение ее размера при полном заполнении
            resizeHashTable();
        }

        int key = i.getKey();
        int hash = hashFunction(key);

        while (arrHash[hash] != null && arrHash[hash].getKey() != -1) {
            if (arrHash[hash].getKey() == key) // выход без вставки
            {
                return false;
            } else {
                ++hash;
                hash = hash % size; // возврат на начало хэш таблицы при увеличении > size
            }
        }
        arrHash[hash] = i;

        countItem++;

        return true;
    }

    public boolean deleteItem(int k) {
        int hash = hashFunction(k);
        int countFind = 0;
        while (arrHash[hash] != null) {
            if (arrHash[hash].getKey() == k) {
                arrHash[hash] = noItem;

                countItem--;

                return true; // удалено
            }
            ++countFind;
            ++hash;
            hash = hash % size;
            if (countFind >= size) {
                return false; // не найден элемент для удаления при полном проходе заполненной хэш таблицы
            }

        }
        return false; // не найдено
    }

    public DataItem findItem(int k) {
        int hash = hashFunction(k);
        int countFind = 0;
        while (arrHash[hash] != null) {
            if (arrHash[hash].getKey() == k) {
                return arrHash[hash]; // вывод найденного объекта
            }
            ++countFind;
            ++hash;
            hash = hash % size;

            if (countFind >= size) {
                return noItem; // не найден элемент при полном проходе заполненной хэш таблицы - не найдено
            }
        }
        return noItem; // -1 - если не найдено, тоже вывожу НетДанных
    }

    public void displayHashTable() {
        System.out.println("HashTable:");
        for (int i = 0; i < size; i++) {
            if (arrHash[i] != null) {
                if (arrHash[i].getKey() != -1) {
                    System.out.print(" " + arrHash[i].getKey() + " ");
                } else {
                    System.out.print(" NoD "); // нет данных после удаления
                }
            } else {
                System.out.print(" ___ ");
            }
        }
        System.out.println("");
    }

    public void resizeHashTable() {
        DataItem[] arrHashNewSize; // новая хеш таблица увеличенного размера
        int key;
        int hash;

        System.out.println("!!! Resize from " + size + " to " + size * 2 + " !!!");

        arrHashNewSize = new DataItem[size * 2]; // модифицированная хеш функция

        for (int i = 0; i < size; i++) { // проход по старой хеш таблице и заполнение новой

            if (arrHash[i] != null) {
                key = arrHash[i].getKey();
            } else {
                key = -1;
            }

            if (arrHash[i] != null && key != -1) {
                hash = hashFunctionNewSize(key);

                while (arrHashNewSize[hash] != null) {
                    ++hash;
                    hash = hash % size;
                }
                arrHashNewSize[hash] = arrHash[i];
            }
        }
        arrHash = arrHashNewSize; // обновление хеш таблицы и ее размера
        size = size * 2;
    }
}
