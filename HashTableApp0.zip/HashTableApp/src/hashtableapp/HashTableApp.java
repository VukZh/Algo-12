package hashtableapp;

public class HashTableApp {

    public static void main(String[] args) {

        HashTable ht1 = new HashTable(5);
        ht1.insertItem(new DataItem(19));
        ht1.displayHashTable();
        ht1.insertItem(new DataItem(0));
        ht1.insertItem(new DataItem(1));
        ht1.insertItem(new DataItem(4));
        ht1.insertItem(new DataItem(3));
        ht1.displayHashTable(); // авторесайз
        ht1.insertItem(new DataItem(10));
        ht1.displayHashTable();

        System.out.println("Find: " + ht1.findItem(3).getKey());    // поиск существующего элемента    
        System.out.println("Find: " + ht1.findItem(11).getKey());    // поиск несуществующего элемента  

        ht1.deleteItem(1111); // удаление несуществующего элемента 
        ht1.deleteItem(0); // удаление несуществующего элемента 
        ht1.displayHashTable();
        ht1.insertItem(new DataItem(11));
        ht1.displayHashTable();
        ht1.insertItem(new DataItem(0));
        ht1.displayHashTable();

        ht1.resizeHashTable();
        ht1.displayHashTable(); // ресайз

    }

}
