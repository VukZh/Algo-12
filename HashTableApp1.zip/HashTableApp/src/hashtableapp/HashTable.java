package hashtableapp;

public class HashTable {

    private DataItem[] arrHash;
    private int size;
    private int countItem;
    private final DataItem noItem = new DataItem(-1); // отметка для ленивого удаления

    HashTable(int s) {
        if (!isPrime(s)) {
            System.out.println("!!!!  число не простое  !!!!");
        }
        size = s;
        arrHash = new DataItem[size];
        countItem = 0;
    }

    private boolean isPrime(int n) { // проверка простого числа
        if (n < 2) {
            return false;
        }
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    private int newSize(int s) {
        for (int i = s * 2 + 1; i < s * 3; i++) { // ищем простое число для нового размера хэш таблицы
            if (isPrime(i)) {
                return i;
            }
        }
        return -1;
    }

    private int hashFunction(int k) { // хэш функция
        return k % size;
    }

    private int hashFunctionNewSize(int k, int newSize) { // хэш функция для нового размера хэш таблицы
        return k % newSize;
    }

    private int probing(int k) { // пробинг
        return k * k;
    }

    public boolean insertItem(DataItem i) { // вставка, при одинаковом элементе - выход без вставки

        if (countItem == size) { // проверка на заполненность хэш таблицы и увеличение ее размера при полном заполнении
            resizeHashTable();
        }

        int key = i.getKey();
        int hash = hashFunction(key);
        int step = 1;

        while (arrHash[hash] != null && arrHash[hash].getKey() != -1) {
            if (arrHash[hash].getKey() == key) // выход без вставки
            {
                return false;
            } else {
                hash = hash + probing(step); /////////////////////////////////////////////////  hash(k)=(hash′(k)+i^2)modM
//                System.out.println("hash inserting: " + hash); // проверка проходов
                step++;
                hash = hash % size; // возврат на начало хэш таблицы при увеличении > size
            }
        }
        arrHash[hash] = i;
        countItem++;
        return true;
    }

    public boolean deleteItem(int k) {
        int hash = hashFunction(k);
        int countFind = 0;
        int step = 1;
        while (arrHash[hash] != null) {
            if (arrHash[hash].getKey() == k) {
                arrHash[hash] = noItem;

                countItem--;

                return true; // удалено
            }
            ++countFind;
            hash = hash + probing(step);
//            System.out.println("hash deleting: " + hash); // проверка проходов
            step++;
            hash = hash % size;

            if (countFind >= size) {
                return false; // не найден элемент для удаления при полном проходе заполненной хэш таблицы
            }

        }
        return false; // не найдено
    }

    public DataItem findItem(int k) {
        int hash = hashFunction(k);
        int countFind = 0;
        int step = 1;
        while (arrHash[hash] != null) {
            if (arrHash[hash].getKey() == k) {
                return arrHash[hash]; // вывод найденного объекта
            }
            ++countFind;
            hash = hash + probing(step);
            System.out.println("hash finding: " + hash); // проверка проходов
            step++;
            hash = hash % size;

            if (countFind >= size) {
                return noItem; // не найден элемент при полном проходе заполненной хэш таблицы - не найдено
            }

        }
        return noItem; // -1 - если не найдено, тоже вывожу НетДанных
    }

    public void displayHashTable() {
        System.out.println("HashTable:");
        for (int i = 0; i < size; i++) {
            if (arrHash[i] != null) {
                if (arrHash[i].getKey() != -1) {
                    System.out.print(" " + arrHash[i].getKey() + " ");
                } else {
                    System.out.print(" NoD "); // нет данных после удаления
                }
            } else {
                System.out.print(" ___ ");
            }
        }
        System.out.println("");
    }

    public void resizeHashTable() { // новая хеш таблица увеличенного размера
        int key;
        int newsize = newSize(size);
        DataItem[] arrHashNewSize = new DataItem[newsize];
        int hash;
        int step;

        System.out.println("!!! Resize from " + size + " to " + newSize(size) + " !!!");

        for (int i = 0; i < size; i++) { // проход по старой хеш таблице и заполнение новой

            step = 1;

            if (arrHash[i] != null) {
                key = arrHash[i].getKey();
            } else {
                key = -1;
            }

            if (arrHash[i] != null && key != -1) {
                hash = hashFunctionNewSize(key, newsize);
                while (arrHashNewSize[hash] != null) {
                    hash = hash + probing(step);
                    step++;
                    hash = hash % newsize;
                }
                arrHashNewSize[hash] = arrHash[i];
            }
        }

        arrHash = arrHashNewSize; // обновление хеш таблицы и ее размера
        size = newsize;

    }
}
