package hashtableapp;

public class DataItem {

    private final int Item;

    public DataItem(int item) {
        Item = item;
    }

    public int getKey() {
        return Item;
    }
}
